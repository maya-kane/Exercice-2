# -*- coding: utf-8 -*-
"""
Created on Mon Oct 24 11:35:25 2022

@author: DELL
"""

import pandas as pd 
import numpy as np 
import seaborn as sns 
import matplotlib.pyplot as plt
#Verifier les jeu de donnees dans seaborn
A=sns.get_dataset_names()
print(A)
#Telechargement des données de diamonds sur la bibliothéque seanborn
df= sns.load_dataset("diamonds")
df.head()
print(df)

#quelques statistiques de base le prix des diamants en fonction de la couleur
sns.set_style("whitegrid")
sns.boxplot(x = 'color', y = 'price', data = df)

#Matrice de correlation qui montre la dépendance des variables

d_num= df[['carat', 'cut', 'color', 'clarity', 'depth', 'table', 'price','x', 'y','z']]
plt.figure(figsize=(12,8))
corr = d_num.corr()
sns.heatmap(corr, cmap="Blues", annot=True)




