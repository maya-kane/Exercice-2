# -*- coding: utf-8 -*-
"""
Created on Mon Oct 24 17:19:11 2022

@author: DELL
"""

import pandas as pd 
import numpy as np 
import seaborn as sns 
import matplotlib.pyplot as plt
#Verifier les jeu de donnees dans seaborn
A=sns.get_dataset_names()
print(A)
#Telechargement des données de diamonds sur la bibliothéque seanborn
df= sns.load_dataset("diamonds")
df.head()
print(df)

#Caractéristique numérique
sns.boxplot(y='price', data=df)
#Histogramme
sns.histplot(x='price', data=df)
sns.displot(df['price'], kde=True)
#Density plot
df.price.plot.density(color='green')
plt.title('Density plot for price')
plt.show()
#Données catégorielles
# countplot
sns.countplot(x= 'color', data=df)
A=df['color'].value_counts(normalize=True)
print(A)

#Visualisation de données multivariées
# relation entre la couleur et la variable prix
sns.boxplot(x='price',y='color', data=df)
# relation entre le prix deux autres variables
sns.boxplot(x='price',y='color', hue='cut', data=df)


