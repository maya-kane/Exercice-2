# -*- coding: utf-8 -*-
"""
Created on Mon Oct 24 17:48:18 2022

@author: DELL
"""

import pandas as pd 
import numpy as np 
import seaborn as sns 
import matplotlib.pyplot as plt
Passager= pd.read_csv("Airpassengers.csv")
print(Passager)
Passager['Month']=pd.to_datetime(Passager['Month'], format='%Y-%m')
print()
Passager['#Passengers'].plot(x='Month', y='#Passengers')